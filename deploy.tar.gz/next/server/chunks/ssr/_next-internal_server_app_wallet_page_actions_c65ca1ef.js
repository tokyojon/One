module.exports=[84232,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_wallet_page_actions_c65ca1ef.js.map