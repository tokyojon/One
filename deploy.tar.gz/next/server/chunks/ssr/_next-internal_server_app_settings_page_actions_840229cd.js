module.exports=[76120,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_settings_page_actions_840229cd.js.map